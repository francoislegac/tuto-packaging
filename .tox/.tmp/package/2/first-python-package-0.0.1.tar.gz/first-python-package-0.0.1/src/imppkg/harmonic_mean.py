def harmonic_mean(l):
    return l[0]
